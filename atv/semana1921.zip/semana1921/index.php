<!DOCTYPE html>
<html>
    <head>
        <title>Semana 19 à 21 de julho de 2021</title>
        <meta charset  = 'utf-8'>
        <link rel="stylesheet" href="assets/css/style.css">
    </head>
    <body>
        <div class="navbar-direita">
            <h1> Semana 19 à 21 de julho de 2021 </h1>
        </div>
        <div class="lateral-esquerda"></div>
        <div class="corpo">
            
            <div class="box-texto">
                <br>
                <a href="form.php">Formularios(19jul2021)</a><br>
                <a href="curriculo.php">Currículo(20jul2021)</a><br>
                <a href="layoutsomente.php">Layout(21jul2021)</a><br>
                <a href="conteudo.php">Layout com conteúdo(21jul2021)</a><br><br>
            </div>
        </div>
        <div class="lateral-direita"></div>
        <div class="footer">
            <br>
        </div>
        
        
    </body>
</html