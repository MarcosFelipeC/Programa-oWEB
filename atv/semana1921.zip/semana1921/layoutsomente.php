<!DOCTYPE html>
<html>

<head>
    <title>LAYOUT</title>
    <meta charset='utf-8'>
    <link rel="stylesheet" href="assets/css/style.css">
</head>

<body>

    <div class="navbar-direita">

        
    </div>
    <br><br>
    <div class="lateral-esquerda"></div>
    <div class="corpo">
        
        <div class="box-texto">
           
        </div>
        <div class="box-texto">
            
        </div>
        <div class="box-texto">
            
        </div>
    </div>
    <div class="lateral-direita"></div>
    <div class="footer">
        <br>
    </div>

</body>

</html>