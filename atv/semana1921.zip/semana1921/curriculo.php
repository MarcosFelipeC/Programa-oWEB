<!DOCTYPE html>
<html>

<head>
    <title>Marcos Felipe</title>
    <meta charset='utf-8'>
    <link rel="stylesheet" href="assets/css/style1.css">
</head>

<body>
    <div id="titulo" class="titulo">

        <h1 class="paragrafo-01">Sobre mim</h1>
    </div>
    <div id="box-right" class="box-right"></div>
    <br>
    <div id="conteudoprincipal" class="conteudoprincipal">


        <img class="foto" src="assets/image/photo.jpg" alt="minha foto" style="width:100px;height=100px">
        <h2 class="paragrafo-03">Marcos Felipe</h2>
        <h2 class="paragrafo-02" Nascido em 10 de julho de 2001</h2>
            <h2 class="paragrafo-02">Cidade: Fortaleza</h2>
            <h2 class="paragrafo-02">Bairro: Parque Dois Irmãos</h2>
            <h2 class="paragrafo-02">Ocupação: Bolsista</h2>
            <br>
            <h2 class="paragrafo-02">Gosto de eletrônica, robótica, programação e leitura</h2>
            <h2 class="paragrafo-02">Tenho como um dos meus hobbies colecionar LP's</h2>

    </div>
    <div class="footer">
        <a class="paragrafo-04" href="https://github.com/MarcosFelipeC">Link do GitHub</a>
    </div>
</body>

</html
